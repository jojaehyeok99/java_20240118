package vehicleApp;

// 탈것 인터페이스
public interface Vehicle {
	
	void accelerate();   // 가속 기능
    void stop();         // 정차 기능
    void setStart(boolean start);  // 시동 기능
	
}
