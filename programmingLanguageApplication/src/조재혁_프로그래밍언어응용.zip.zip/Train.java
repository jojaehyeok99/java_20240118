package vehicleApp;

// 열차
public class Train implements Vehicle {
	
	private String trainNumber; // 열차번호
	private String departureStation; // 출발역
	private String arrivalStation; // 도착역
	private boolean isStart; // 시동상태
	
	public Train(String trainNumber, String departureStation, String arrivalStation, boolean isStart) {
	    this.trainNumber = trainNumber;
	    this.departureStation = departureStation;
	    this.arrivalStation = arrivalStation;
	    this.isStart = isStart;}
	        
	@Override
	public void accelerate() {
		System.out.println("열차가 가속합니다!");
		
	}
	
	@Override
	public void stop() {
		System.out.println("열차가 정차합니다!");
		
	}
	
	@Override
	public void setStart(boolean start) {
		this.isStart = start;
		
	}
	
	public String getTrainNumber() {
        return trainNumber;
    }

    public String getDepartureStation() {
        return departureStation;
    }

    public String getArrivalStation() {
        return arrivalStation;
    }

    public boolean isStart() {
        return isStart;
    }
}
