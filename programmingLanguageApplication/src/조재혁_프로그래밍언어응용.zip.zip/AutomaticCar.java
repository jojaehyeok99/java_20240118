package vehicleApp;

// 자동 변속기 자동차
public class AutomaticCar extends Car {
	
	public AutomaticCar(String vin, String color, boolean isStart) {
        super(vin, color, isStart);
    }
	
    @Override
    public void accelerate() {
        System.out.println("자동변속기 자동차가 가속합니다!");
    }
}

