package vehicleApp;

// 수동 변속기 자동차
public class ManualCar extends Car {
	
	private int gear;
	
	public ManualCar(String vin, String color, boolean isStart, int gear) {
	        super(vin, color, isStart);
	        this.gear = gear;
	 }
	
	@Override
	public void accelerate() {
		System.out.println("수동변속기 자동차가 가속합니다!");
	}
	
	@Override
	public void stop() {
		System.out.println("수동변속기 자동차가 정차합니다!");
		super.stop();
	}

	public int getGear() {
        return gear;
    }
}
